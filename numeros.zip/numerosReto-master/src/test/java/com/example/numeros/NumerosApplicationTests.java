package com.example.numeros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NumerosApplicationTests {

	@Test
	void contextLoads() {
	}

}
