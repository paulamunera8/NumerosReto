package com.example.numeros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NumerosApplication {

	public static void main(String[] args) {
		SpringApplication.run(NumerosApplication.class, args);
	}

}
